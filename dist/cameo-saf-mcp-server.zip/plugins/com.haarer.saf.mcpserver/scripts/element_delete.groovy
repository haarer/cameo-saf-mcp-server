// delete_element moved to element_crud.groovy
